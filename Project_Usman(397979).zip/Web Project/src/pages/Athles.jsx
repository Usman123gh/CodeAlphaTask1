import React, { useState } from 'react';
import './Athles.css'; 
import axios from 'axios'; 
import call from '../Images/pic1.avif';
import yo from '../Images/pic2.webp';
import calls from '../Images/pic3.avif';
import yos from '../Images/pic4.avif';
import yosa from '../Images/pic5.avif';
import yosq from '../Images/pic6.avif';
import yose from '../Images/pic7.avif';
import yosr from '../Images/pic8.avif';

const products = [
  { id: 1, name: 'Athleisure US-EX-3205', price: 11999, images: [call, yo] },
  { id: 2, name: 'Athleisure US-EX-3205', price: 11999, images: [calls, yos] },
  { id: 3, name: 'Jogger EX-1351', price: 7199, images: [yosa,yosq ] },
  { id: 4, name: 'Jogger EX-1351', price: 7199, images: [yose,yosr ] },
];

const BootsPage = () => {
  const [hoveredProduct, setHoveredProduct] = useState(null);

  const handleMouseEnter = (id) => {
    setHoveredProduct(id);
  };

  const handleMouseLeave = () => {
    setHoveredProduct(null);
  };

  const handleQuickShop = async (product) => {
    const imageUrl = product.images[0];
  
    console.log('Sending data to backend:', { 
      productId: product.id, 
      name: product.name, 
      price: product.price, 
      imageUrl 
    });
    
    try {
      const response = await axios.post('http://localhost:5000/add', {
        productId: product.id,
        name: product.name,
        price: product.price,
        imageUrl, 
      });
      console.log('Response from backend:', response.data);
      alert('Item added to cart!');
    } catch (error) {
      console.error('Error adding item to cart:', error);
      alert('Failed to add item to cart.');
    }
  };
  

  return (
    <div className="boots-page">
      <div className="breadcrumbs">
        <a href="/">Home</a> &gt; <span>Athleisure</span>
      </div>
      <h1>Athleisure</h1>
      <div className="content">
        <div className="filters">
          <h3>Filters</h3>
          <div className="filter-section">
            <h4>Price</h4>
            <div className="price-filter">
              <input type="number" placeholder="Rs From" />
              <input type="number" placeholder="Rs To" />
            </div>
          </div>
          <div className="filter-section">
            <h4>Size</h4>
            <div className="size-filter">
              <input type="checkbox" id="size39" />
              <label htmlFor="size39">39</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size40" />
              <label htmlFor="size40">40</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size41" />
              <label htmlFor="size41">41</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size42" />
              <label htmlFor="size42">42</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size43" />
              <label htmlFor="size43">43</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size44" />
              <label htmlFor="size44">44</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size45" />
              <label htmlFor="size45">45</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size46" />
              <label htmlFor="size46">46</label>
            </div>
          </div>
        </div>
        <div className="products">
          <div className="sort-options">
            <label htmlFor="sort">Sort by:</label>
            <select id="sort">
              <option value="date-new-to-old">Date, new to old</option>
              <option value="date-old-to-new">Date, old to new</option>
              <option value="price-low-to-high">Price, low to high</option>
              <option value="price-high-to-low">Price, high to low</option>
            </select>
          </div>
          <div className="product-grid">
            {products.map((product) => (
              <div
                key={product.id}
                className="product-card"
                onMouseEnter={() => handleMouseEnter(product.id)}
                onMouseLeave={handleMouseLeave}
              >
                <img
                  src={hoveredProduct === product.id ? product.images[1] : product.images[0]}
                  alt={product.name}
                />
                <p>{product.name}</p>
                <p>Rs.{product.price}</p>
                <button className="quick-shop" onClick={() => handleQuickShop(product)}>Quick shop</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BootsPage;
