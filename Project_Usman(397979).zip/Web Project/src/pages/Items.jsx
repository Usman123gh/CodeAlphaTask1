import React, { useState } from 'react';
import axios from 'axios'; // Fixed import
import './Items.css';
import home1 from '../Images/home1.avif';
import home2 from '../Images/home2.avif';
import home3 from '../Images/home3.avif';
import home4 from '../Images/home4.avif';
import home5 from '../Images/home5.webp';
import home6 from '../Images/home6.avif';
import home7 from '../Images/home7.avif';
import home8 from '../Images/home8.avif';
import home9 from '../Images/home9.avif';
import home10 from '../Images/home10.avif';
import home11 from '../Images/home11.avif';
import home12 from '../Images/home12.avif';
import home13 from '../Images/home13.avif';
import home14 from '../Images/home14.avif';
import home15 from '../Images/home15.avif';
import home16 from '../Images/home16.avif';
import home17 from '../Images/home17.avif';
import home18 from '../Images/home18.avif';
import home19 from '../Images/home19.webp';
import home20 from '../Images/home20.avif';

const products = [
  { id: 1, name: 'SANDAL US-AX-4105', price: 8199, images: [home1, home2] },
  { id: 2, name: 'SANDAL US-AX-4105', price: 5999, images: [home3, home4] },
  { id: 3, name: 'SANDAL US-AX-4105', price: 5999, images: [home5, home6] },
  { id: 4, name: 'Apertus US-JM-4352', price: 5999, images: [home7, home8] },
  { id: 5, name: 'Coastwalker US-JM-4353', price: 5999, images: [home9, home10] },
  { id: 6, name: 'Albergo US-JM-4301', price: 6299, images: [home11, home12] },
  { id: 7, name: 'Sandstorm US-MC-4152', price: 6399, images: [home13, home14] },
  { id: 8, name: 'Sentorum US-JM-4302', price: 6299, images: [home15, home16] },
  { id: 9, name: 'Slipper PC-DV-4353', price: 4995, images: [home17, home18] },
  { id: 10, name: 'Slipper PC-DV-4353', price: 4995, images: [home19, home20] },
];

const ProductGrid = () => {
  const [startIndex, setStartIndex] = useState(0);
  const [hoveredProduct, setHoveredProduct] = useState(null);
  const itemsPerPage = 5;

  const handleNext = () => {
    setStartIndex((prevIndex) => Math.min(prevIndex + itemsPerPage, products.length - itemsPerPage));
  };

  const handlePrev = () => {
    setStartIndex((prevIndex) => Math.max(prevIndex - itemsPerPage, 0));
  };

  const currentProducts = products.slice(startIndex, startIndex + itemsPerPage);

  const handleMouseEnter = (id) => {
    setHoveredProduct(id);
  };

  const handleMouseLeave = () => {
    setHoveredProduct(null);
  };

  const handleQuickShop = async (product) => {
    const imageUrl = product.images[0];
  
    console.log('Sending data to backend:', { 
      productId: product.id, 
      name: product.name, 
      price: product.price, 
      imageUrl 
    });
    
    try {
      const response = await axios.post('http://localhost:5000/add', {
        productId: product.id,
        name: product.name,
        price: product.price,
        imageUrl, 
      });
      console.log('Response from backend:', response.data);
      alert('Item added to cart!');
    } catch (error) {
      console.error('Error adding item to cart:', error);
      alert('Failed to add item to cart.');
    }
  };
  
  
  return (
    <div className="custom-page">
      <div className="custom-product-grid-container">
        <button className="navigation-button left" onClick={handlePrev} disabled={startIndex === 0}>❮</button>
        <div className="custom-product-grid">
          {currentProducts.map((product) => (
            <div
              key={product.id}
              className="custom-product-card"
              onMouseEnter={() => handleMouseEnter(product.id)}
              onMouseLeave={handleMouseLeave}
            >
              <img
                src={hoveredProduct === product.id ? product.images[1] : product.images[0]}
                alt={product.name}
              />
              <p>{product.name}</p>
              <p>Rs.{product.price}</p>
              <button className="custom-quick-shop" onClick={() => handleQuickShop(product)}>Quick shop</button>
            </div>
          ))}
        </div>
        <button className="navigation-button right" onClick={handleNext} disabled={startIndex >= products.length - itemsPerPage}>❯</button>
      </div>
    </div>
  );
};

export default ProductGrid;
