import React, { useState } from 'react';
import './Athles.css'; 
import axios from 'axios'; 
import woboots1 from '../Images/woboots1.avif';
import woboots2 from '../Images/woboots2.webp';
import woboots3 from '../Images/woboots3.avif';
import woboots4 from '../Images/woboots4.avif';
import woboots5 from '../Images/woboots5.jpeg';
import woboots6 from '../Images/woboots6.webp';
import woboots7 from '../Images/woboots7.avif';
import woboots8 from '../Images/woboots8.avif';
import woboots9 from '../Images/woboots9.avif';
import woboots10 from '../Images/woboots10.webp';

const products = [
  { id: 1, name: 'Boot US-JT-3102', price: 9999, images: [woboots1,woboots2 ] },
  { id: 2, name: 'Boot US-JT-3102', price: 9999, images: [woboots3,woboots4 ] },
  { id: 3, name: 'Boot US-TD-3103', price: 9999, images: [woboots5,woboots6 ] },
  { id: 4, name: 'Boot US-JT-3102', price: 9999, images: [woboots7,woboots8 ] },
  { id: 5, name: 'Boot US-TD-3103', price: 9999, images: [woboots9,woboots10 ] },
];

const BootsPage = () => {
  const [hoveredProduct, setHoveredProduct] = useState(null);

  const handleMouseEnter = (id) => {
    setHoveredProduct(id);
  };

  const handleMouseLeave = () => {
    setHoveredProduct(null);
  };

  const handleQuickShop = async (product) => {
    const imageUrl = product.images[0];
  
    console.log('Sending data to backend:', { 
      productId: product.id, 
      name: product.name, 
      price: product.price, 
      imageUrl 
    });
    
    try {
      const response = await axios.post('http://localhost:5000/add', {
        productId: product.id,
        name: product.name,
        price: product.price,
        imageUrl, 
      });
      console.log('Response from backend:', response.data);
      alert('Item added to cart!');
    } catch (error) {
      console.error('Error adding item to cart:', error);
      alert('Failed to add item to cart.');
    }
  };
  

  return (
    <div className="boots-page">
      <div className="breadcrumbs">
        <a href="/">Home</a> &gt; <span>Women Boots</span>
      </div>
      <h1>Women Boots</h1>
      <div className="content">
        <div className="filters">
          <h3>Filters</h3>
          <div className="filter-section">
            <h4>Price</h4>
            <div className="price-filter">
              <input type="number" placeholder="Rs From" />
              <input type="number" placeholder="Rs To" />
            </div>
          </div>
          <div className="filter-section">
            <h4>Size</h4>
            <div className="size-filter">
              <input type="checkbox" id="size39" />
              <label htmlFor="size39">39</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size40" />
              <label htmlFor="size40">40</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size41" />
              <label htmlFor="size41">41</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size42" />
              <label htmlFor="size42">42</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size43" />
              <label htmlFor="size43">43</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size44" />
              <label htmlFor="size44">44</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size45" />
              <label htmlFor="size45">45</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size46" />
              <label htmlFor="size46">46</label>
            </div>
          </div>
        </div>
        <div className="products">
          <div className="sort-options">
            <label htmlFor="sort">Sort by:</label>
            <select id="sort">
              <option value="date-new-to-old">Date, new to old</option>
              <option value="date-old-to-new">Date, old to new</option>
              <option value="price-low-to-high">Price, low to high</option>
              <option value="price-high-to-low">Price, high to low</option>
            </select>
          </div>
          <div className="product-grid">
            {products.map((product) => (
              <div
                key={product.id}
                className="product-card"
                onMouseEnter={() => handleMouseEnter(product.id)}
                onMouseLeave={handleMouseLeave}
              >
                <img
                  src={hoveredProduct === product.id ? product.images[1] : product.images[0]}
                  alt={product.name}
                />
                <p>{product.name}</p>
                <p>Rs.{product.price}</p>
                <button className="quick-shop" onClick={() => handleQuickShop(product)}>Quick shop</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BootsPage;
