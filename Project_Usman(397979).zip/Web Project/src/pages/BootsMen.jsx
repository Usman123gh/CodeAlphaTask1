import React, { useState } from 'react';
import './Athles.css'; 
import axios from 'axios'; 
import boots1 from '../Images/boots1.avif';
import boots2 from '../Images/boots2.avif';
import boots3 from '../Images/boots3.avif';
import boots4 from '../Images/boots4.avif';
import boots5 from '../Images/boots5.avif';
import boots6 from '../Images/boots6.jpeg';
import boots7 from '../Images/boots7.jpg';
import boots8 from '../Images/boots8.avif';
import boots9 from '../Images/boots9.avif';
import boots10 from '../Images/boots10.avif';
import boots11 from '../Images/boots11.avif';
import boots12 from '../Images/boots12.jpeg';
import boots13 from '../Images/boots13.avif';
import boots14 from '../Images/boots14.jpeg';

const products = [
  { id: 1, name: 'Ultar IT-1101', price: 11995, images: [boots1,boots2 ] },
  { id: 2, name: 'Ultar IT-1101', price: 11995, images: [boots4,boots3 ] },
  { id: 3, name: 'Ultar IT-1101', price: 11995, images: [boots5,boots6 ] },
  { id: 4, name: 'Sigal IT-1102', price: 11995, images: [boots7,boots8 ] },
  { id: 5, name: 'Karambar IT-1103', price: 11995, images: [boots9,boots10 ] },
  { id: 6, name: 'Karambar IT-1103', price: 11995, images: [boots11,boots12 ] },
  { id: 7, name: 'Boot TR-2101', price: 10999, images: [boots13,boots14 ] },
];

const BootsPage = () => {
  const [hoveredProduct, setHoveredProduct] = useState(null);

  const handleMouseEnter = (id) => {
    setHoveredProduct(id);
  };

  const handleMouseLeave = () => {
    setHoveredProduct(null);
  };

  const handleQuickShop = async (product) => {
    const imageUrl = product.images[0];
  
    console.log('Sending data to backend:', { 
      productId: product.id, 
      name: product.name, 
      price: product.price, 
      imageUrl 
    });
    
    try {
      const response = await axios.post('http://localhost:5000/add', {
        productId: product.id,
        name: product.name,
        price: product.price,
        imageUrl, 
      });
      console.log('Response from backend:', response.data);
      alert('Item added to cart!');
    } catch (error) {
      console.error('Error adding item to cart:', error);
      alert('Failed to add item to cart.');
    }
  };
  

  return (
    <div className="boots-page">
      <div className="breadcrumbs">
        <a href="/">Home</a> &gt; <span>Men Boots</span>
      </div>
      <h1>Men Boots</h1>
      <div className="content">
        <div className="filters">
          <h3>Filters</h3>
          <div className="filter-section">
            <h4>Price</h4>
            <div className="price-filter">
              <input type="number" placeholder="Rs From" />
              <input type="number" placeholder="Rs To" />
            </div>
          </div>
          <div className="filter-section">
            <h4>Size</h4>
            <div className="size-filter">
              <input type="checkbox" id="size39" />
              <label htmlFor="size39">39</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size40" />
              <label htmlFor="size40">40</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size41" />
              <label htmlFor="size41">41</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size42" />
              <label htmlFor="size42">42</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size43" />
              <label htmlFor="size43">43</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size44" />
              <label htmlFor="size44">44</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size45" />
              <label htmlFor="size45">45</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size46" />
              <label htmlFor="size46">46</label>
            </div>
          </div>
        </div>
        <div className="products">
          <div className="sort-options">
            <label htmlFor="sort">Sort by:</label>
            <select id="sort">
              <option value="date-new-to-old">Date, new to old</option>
              <option value="date-old-to-new">Date, old to new</option>
              <option value="price-low-to-high">Price, low to high</option>
              <option value="price-high-to-low">Price, high to low</option>
            </select>
          </div>
          <div className="product-grid">
            {products.map((product) => (
              <div
                key={product.id}
                className="product-card"
                onMouseEnter={() => handleMouseEnter(product.id)}
                onMouseLeave={handleMouseLeave}
              >
                <img
                  src={hoveredProduct === product.id ? product.images[1] : product.images[0]}
                  alt={product.name}
                />
                <p>{product.name}</p>
                <p>Rs.{product.price}</p>
                <button className="quick-shop" onClick={() => handleQuickShop(product)}>Quick shop</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BootsPage;
