import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Cart.css'; 

const Cart = () => {
  const [items, setItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    try {
      const response = await axios.get('http://localhost:5000/items');
      const fetchedItems = response.data;

      setItems(fetchedItems);

    
      const total = fetchedItems.reduce((sum, item) => sum + Number(item.price) * Number(item.quantity), 0);
      setTotalPrice(total);
    } catch (error) {
      console.error('Error fetching cart items:', error);
    }
  };

  const handleQuantityChange = async (id, newQuantity) => {
    try {
      await axios.put(`http://localhost:5000/items/${id}`, { quantity: newQuantity });
      fetchItems();
    } catch (error) {
      console.error('Error updating item quantity:', error);
    }
  };

  const handleDeleteItem = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/items/${id}`);
      fetchItems(); 
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const handleCheckout = async () => {
    try {
      await axios.delete('http://localhost:5000/clear');
      setItems([]);
      setTotalPrice(0);
      alert('Checkout successful!');
    } catch (error) {
      console.error('Error during checkout:', error);
    }
  };

  const handleContinueShopping = () => {
    window.location.href = '/';
  };

  return (
    <div className="cart-container">
      <h2>Your Cart</h2>
      {items.length === 0 ? (
        <div className="empty-cart">
          <p>Your cart is empty</p>
          <button onClick={handleContinueShopping} className="continue-shopping-button">
            <i className="fas fa-shopping-cart"></i> Continue shopping
          </button>
        </div>
      ) : (
        <div className="cart-items-box">
          {items.map(item => (
            <div key={item._id} className="cart-item">
              <img src={item.imageUrl} alt={item.name} className="cart-item-image" />
              <div className="cart-item-details">
                <p>{item.name}</p>
                <p>Price: Rs.{item.price}</p>
              </div>
              <div className="cart-item-actions">
                <select
                  value={item.quantity}
                  onChange={(e) => handleQuantityChange(item._id, parseInt(e.target.value))}
                >
                  {[...Array(10).keys()].map(n => (
                    <option key={n + 1} value={n + 1}>{n + 1}</option>
                  ))}
                </select>
                <p>Rs.{item.price * Number(item.quantity)}</p>
                <button onClick={() => handleDeleteItem(item._id)}>×</button>
              </div>
            </div>
          ))}
          <div className="cart-subtotal">
            <h3>Subtotal: Rs.{totalPrice}</h3>
            <button onClick={handleCheckout} className="checkout-button">
              <i className="fas fa-shopping-cart"></i> Check out
            </button>
          </div>
        </div>
      )}
      <button onClick={handleContinueShopping} className="continue-shopping-button">
        Continue shopping
      </button>
    </div>
  );
};

export default Cart;
