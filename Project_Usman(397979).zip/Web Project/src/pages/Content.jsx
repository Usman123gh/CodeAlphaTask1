import React from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import './Content.css'; 
import slide1 from '../Images/slide1.webp'; 
import slide2 from '../Images/slide2.webp'; 
import slide3 from '../Images/slide3.webp';
import slide4 from '../Images/slide 4.webp';
import slide5 from '../Images/slide5.webp';
import slide6 from '../Images/slide6.webp';
import shipping from '../Images/1.jpg'; 
import call from '../Images/2.jpg'; 
import delivery from '../Images/3.jpg'; 
import support from '../Images/4.jpg'; 
import promo from '../Images/promo.webp'; 

function Slideshow() {
  const slides = [
    { img: slide1, alt: 'Slide 1' },
    { img: slide2, alt: 'Slide 2' },
    { img: slide3, alt: 'Slide 3' },
    { img: slide4, alt: 'Slide 4' },
    { img: slide5, alt: 'Slide 5' },    
    { img: slide6, alt: 'Slide 6' },

  ];

  return (
    <Carousel showThumbs={false} autoPlay infiniteLoop>
      {slides.map((slide, index) => (
        <div key={index}>
          <img src={slide.img} alt={slide.alt} className="carousel-image" />
        </div>
      ))}
    </Carousel>
  );
}

function InfoSection() {
  const infoItems = [
    {
      icon: shipping,
      title: 'Standard Shipping',
      description: 'PKR 150 will be charged on all orders'
    },
    {
      icon: call, 
      title: 'Give Us A Call',
      description: '+923460000128'
    },
    {
      icon: delivery, 
      title: 'Delivery',
      description: 'Orders shall be delivered in 5 to 7 Business days'
    },
    {
      icon: support, 
      title: 'Customer Support',
      description: '9:30am to 5:30pm (EST)'
    }
  ];

  return (
    <div className="info-section">
      {infoItems.map((item, index) => (
        <div className="info-item" key={index}>
          <img src={item.icon} alt={item.title} className="info-icon" />
          <div className="info-content">
            <h4>{item.title}</h4>
            <p>{item.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
function PromoSection() {
  return (
    <div className="promo-section">
      <div className="promo-content">
        <h2>ATHLEISURE</h2>
        <p>Urbansole offers the coziest and smart shoes. With Xceed, we offer the best blend of both style and ease, keeping you elegant all the way.</p>
        <button className="shop-now-button">Shop Now</button>
      </div>
      <div className="promo-image">
        <img src={promo} alt="Promo" />
      </div>
    </div>
  );
}


function Content() {
  return (
    <div>
      <Slideshow />
      <InfoSection />
      <PromoSection />
      
    </div>
  );
}

export default Content;