import React, { useState } from 'react';
import './Athles.css'; 
import axios from 'axios';
import moca1 from '../Images/moca1.avif';
import moca2 from '../Images/moca2.jpeg';
import moca3 from '../Images/moca3.avif';
import moca4 from '../Images/moca4.jpeg';
import moca5 from '../Images/moca5.avif';
import moca6 from '../Images/moca6.jpeg';
import moca7 from '../Images/moca7.avif';
import moca8 from '../Images/moca8.avif';
import moca9 from '../Images/moca9.avif';
import moca10 from '../Images/moca10.avif';
import moca11 from '../Images/moca11.avif';
import moca12 from '../Images/moca12.avif';
import moca13 from '../Images/moca13.jpeg';
import moca14 from '../Images/moca14.jpeg';

const products = [
  { id: 1, name: 'Shoe Moc US-DS-3311', price: 4199, images: [moca1,moca2 ] },
  { id: 2, name: 'Shoe Moc US-DS-3312', price: 4199, images: [moca3,moca4 ] },
  { id: 3, name: 'Shoe Moc US-NV-3301', price: 3499, images: [moca5,moca6 ] },
  { id: 4, name: 'Shoe Moc US-NV-3302', price: 3999, images: [moca7,moca8 ] },
  { id: 5, name: 'Shoe Moc US-DS-3311', price: 4199, images: [moca9,moca10 ] },
  { id: 6, name: 'Shoe Moc US-NV-3302', price: 3999, images: [moca11,moca12 ] },
  { id: 7, name: 'Shoe Moc US-NV-3301', price: 3499, images: [moca13,moca14 ] },
];

const BootsPage = () => {
  const [hoveredProduct, setHoveredProduct] = useState(null);

  const handleMouseEnter = (id) => {
    setHoveredProduct(id);
  };

  const handleMouseLeave = () => {
    setHoveredProduct(null);
  };

  const handleQuickShop = async (product) => {
    const imageUrl = product.images[0];
  
    console.log('Sending data to backend:', { 
      productId: product.id, 
      name: product.name, 
      price: product.price, 
      imageUrl 
    });
    
    try {
      const response = await axios.post('http://localhost:5000/add', {
        productId: product.id,
        name: product.name,
        price: product.price,
        imageUrl, 
      });
      console.log('Response from backend:', response.data);
      alert('Item added to cart!');
    } catch (error) {
      console.error('Error adding item to cart:', error);
      alert('Failed to add item to cart.');
    }
  };
  

  return (
    <div className="boots-page">
      <div className="breadcrumbs">
        <a href="/">Home</a> &gt; <span>Women Moccasin</span>
      </div>
      <h1>Women Moccasin</h1>
      <div className="content">
        <div className="filters">
          <h3>Filters</h3>
          <div className="filter-section">
            <h4>Price</h4>
            <div className="price-filter">
              <input type="number" placeholder="Rs From" />
              <input type="number" placeholder="Rs To" />
            </div>
          </div>
          <div className="filter-section">
            <h4>Size</h4>
            <div className="size-filter">
              <input type="checkbox" id="size39" />
              <label htmlFor="size39">39</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size40" />
              <label htmlFor="size40">40</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size41" />
              <label htmlFor="size41">41</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size42" />
              <label htmlFor="size42">42</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size43" />
              <label htmlFor="size43">43</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size44" />
              <label htmlFor="size44">44</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size45" />
              <label htmlFor="size45">45</label>
            </div>
            <div className="size-filter">
              <input type="checkbox" id="size46" />
              <label htmlFor="size46">46</label>
            </div>
          </div>
        </div>
        <div className="products">
          <div className="sort-options">
            <label htmlFor="sort">Sort by:</label>
            <select id="sort">
              <option value="date-new-to-old">Date, new to old</option>
              <option value="date-old-to-new">Date, old to new</option>
              <option value="price-low-to-high">Price, low to high</option>
              <option value="price-high-to-low">Price, high to low</option>
            </select>
          </div>
          <div className="product-grid">
            {products.map((product) => (
              <div
                key={product.id}
                className="product-card"
                onMouseEnter={() => handleMouseEnter(product.id)}
                onMouseLeave={handleMouseLeave}
              >
                <img
                  src={hoveredProduct === product.id ? product.images[1] : product.images[0]}
                  alt={product.name}
                />
                <p>{product.name}</p>
                <p>Rs.{product.price}</p>
                <button className="quick-shop" onClick={() => handleQuickShop(product)}>Quick shop</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BootsPage;
