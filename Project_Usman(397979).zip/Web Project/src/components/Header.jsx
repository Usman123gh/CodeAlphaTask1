import React from 'react';
import { Link } from 'react-router-dom';
import '@fortawesome/fontawesome-free/css/all.min.css';
import './Header.css';
import logo from '../Images/logo.avif';

const Header = () => {
  const handleUnderConstruction = (event) => {
    event.preventDefault();
    alert('This page is under construction');
  };

  return (
    <header className="header">
      <div className="top-bar">
        <div className="logo">
          <a href="/">
            <img src={logo} alt="Logo" />
          </a>
        </div>
        <div className="search-bar">
          <select className="category-select">
            <option>All categories</option>
            <option>--------------</option>
            <option>KIDS</option>
            <option>MEN</option>
            <option>WOMEN</option>
          </select>
          <input type="text" placeholder="What are you looking for?" />
          <button className="search-button">
            <i className="fas fa-search"></i>
          </button>
        </div>
        <div className="user-controls">
        <a href="/" className="login"><i className="fas fa-user"></i> Login</a>
        <Link to="/cart"><i className="fas fa-shopping-bag"></i></Link>
        </div>
      </div>
      <nav className="nav-links">
        <div className="nav-item">
          <Link to="/skooler">SKOOLERS</Link>
        </div>
        <div className="nav-item">
          <a href="/" className="sale">SALE</a>
        </div>
        <div className="nav-item">
          <a href="/" className='new-in'>NEW IN</a>
        </div>
        <div className="nav-item">
          <a href="/" className='sports'>SPORTS SHOES</a>
        </div>
        <div className="nav-item">
          <a href="/">MEN</a>
          <div className="dropdown-content">
            <Link to="/athles">ATHLEISURE</Link>
            <Link to="/bootsmen">BOOTS</Link>
            <Link to="" onClick={handleUnderConstruction}>CASUAL SHOES</Link>
            <a href="" onClick={handleUnderConstruction}>FORMAL SHOE</a>
            <a href="" onClick={handleUnderConstruction}>LOAFERS</a>
            <a href="" onClick={handleUnderConstruction}>PESHAWARI</a>
            <a href="" onClick={handleUnderConstruction}>SANDAL</a>
            <a href="" onClick={handleUnderConstruction}>SLIDER</a>
            <a href="" onClick={handleUnderConstruction}>SLIPPER</a>
            <a href="" onClick={handleUnderConstruction}>SNEAKER</a>
          </div>
        </div>
        <div className="nav-item">
          <a href="/">WOMEN</a>
          <div className="dropdown-content">
            <Link to="/bootswomen">BOOTS</Link>
            <Link to="/moccasin">MOCCASIN</Link>
            <a href="" onClick={handleUnderConstruction}>PUMPO</a>
            <a href="" onClick={handleUnderConstruction}>SANDAL</a>
            <a href="" onClick={handleUnderConstruction}>SLIDER</a>
            <a href="" onClick={handleUnderConstruction}>SLIPPER</a>
          </div>
        </div>
        <div className="nav-item">
          <a href="/">KIDS</a>
          <div className="dropdown-content">
            <Link to="/skooler">SKOOLERS</Link>
          </div>
        </div>
        <div className="nav-item">
          <a href="/">ACCESSORIES</a>
          <div className="dropdown-content">
            <a href="" onClick={handleUnderConstruction}>SOOCKS</a>
            <a href="" onClick={handleUnderConstruction}>BELTS</a>
            <a href="" onClick={handleUnderConstruction}>WALLETS</a>
            <a href="" onClick={handleUnderConstruction}>SHOE CARE</a>
            <a href="" onClick={handleUnderConstruction}>INSOLE</a>
          </div>
        </div>
        <div className="nav-item">
          <a href="/">TECHNOLOGY</a>
          <div className="dropdown-content">
            <a href="" onClick={handleUnderConstruction} className='ecosole'>ECOSOLE</a>
            <a href="" onClick={handleUnderConstruction}>FLEX</a>
            <a href="" onClick={handleUnderConstruction}>HYPERFLEX</a>
            <a href="" onClick={handleUnderConstruction}>REFLEXOLE</a>
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Header;
