import React from 'react';
import './Footer.css';


function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section follow-us">
          <h4>Follow us</h4>
          <div className="social-icons">
            <a href="#"><i className="fab fa-facebook-f"></i></a>
            <a href="#"><i className="fab fa-instagram"></i></a>
            <a href="#"><i className="fab fa-youtube"></i></a>
            <a href="#"><i className="fab fa-linkedin-in"></i></a>
            <a href="#"><i className="fas fa-envelope"></i></a>
          </div>
        </div>
        <div className="footer-section menu">
          <h4>Menu</h4>
          <ul>
            <li><a href="#">SALE</a></li>
            <li><a href="#">NEW IN</a></li>
            <li><a href="#">SPORTS SHOES</a></li>
            <li><a href="#">MEN</a></li>
            <li><a href="#">WOMEN</a></li>
            <li><a href="#">KIDS</a></li>
            <li><a href="#">ACCESSORIES</a></li>
            <li><a href="#">TECHNOLOGY</a></li>
          </ul>
        </div>
        <div className="footer-section customer-services">
          <h4>Customer Services</h4>
          <ul>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Payment Options</a></li>
            <li><a href="#">Blogs</a></li>
            <li><a href="#">Store Locator</a></li>
          </ul>
        </div>
        <div className="footer-section policies">
          <h4>Policies</h4>
          <ul>
            <li><a href="#">Return & Exchange</a></li>
            <li><a href="#">Claim Policy</a></li>
            <li><a href="#">Cancellation Policy</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">FAQ's</a></li>
          </ul>
        </div>
        <div className="footer-section subscribe">
          <h4>Subscribe</h4>
          <form>
            <input type="email" placeholder="Email address" />
            <button type="submit">Sign up</button>
          </form>
        </div>
      </div>
      <div className="footer-section copyright">
        <p>Search</p>
        <p>Copyright © 2024 Urbansole.</p>
        <p>Powered by Shopify</p>
      </div>
    </footer>
  );
}

export default Footer;
