import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import Content from './pages/Content';
import Items from './pages/Items';
import ATHLEISURE from './pages/Athles';
import BOOSTSMEN from './pages/BootsMen';
import BOOTSWOMEN from './pages/BoostWomen';
import MOCCASIN from './pages/Moccasin';
import SKOOLERS from './pages/Skoolers';    
import Header from './components/Header';
import Footer from './components/Footer';
import Cart from './pages/Cart';

const App = () => (
  <Router>
    <Header />
    <main style={{ padding: '20px' }}>
      <Routes>
        <Route exact path="/" element={
          <>
            <Content />
            <Items />
          </>
        } />
        <Route path="/athles" element={<ATHLEISURE />} />
        <Route path="/bootsmen" element={<BOOSTSMEN />} />
        <Route path="/bootswomen" element={<BOOTSWOMEN />} />
        <Route path="/moccasin" element={<MOCCASIN />} />
        <Route path="/skooler" element={<SKOOLERS />} />  
        <Route path="/cart" element={<Cart />} />  
      </Routes>
    </main>
    <Footer />
  </Router>
);

export default App;
