const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

app.use(cors()); 
app.use(bodyParser.json());

mongoose.connect('mongodb://127.0.0.1:27017/Urbansole', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

const CartItemSchema = new mongoose.Schema({
  productId: {
    type: Number,
    required: true,
  },
  name: String,
  imageUrl: String, 
  price: {
    type: Number,
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
    default: 1, 
  },
});

const CartItem = mongoose.model('CartItem', CartItemSchema);

app.post('/add', async (req, res) => {
  try {
    console.log('Request received:', req.body);
    const { productId, name, price, imageUrl } = req.body; 

    if (!productId || !name || !price || !imageUrl) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const newCartItem = new CartItem({
      productId,
      name,
      price,
      imageUrl, 
    });

    const savedItem = await newCartItem.save();
    console.log('Item saved to database:', savedItem);

    res.status(201).json({ message: 'Item added to cart successfully', item: savedItem });
  } catch (error) {
    console.error('Error adding item to cart:', error);
    res.status(500).json({ message: 'Failed to add item to cart' });
  }
});

app.get('/items', async (req, res) => {
  try {
    const items = await CartItem.find();
    res.status(200).json(items);
  } catch (error) {
    console.error('Error fetching cart items:', error);
    res.status(500).json({ message: 'Failed to fetch cart items' });
  }
});

app.put('/items/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { quantity } = req.body;

    const updatedItem = await CartItem.findByIdAndUpdate(id, { quantity }, { new: true });
    res.status(200).json(updatedItem);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update item quantity' });
  }
});

app.delete('/items/:id', async (req, res) => {
  try {
    const { id } = req.params;

    await CartItem.findByIdAndDelete(id);
    res.status(200).json({ message: 'Item deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete item' });
  }
});

app.delete('/clear', async (req, res) => {
  try {
    await CartItem.deleteMany({});
    res.status(200).json({ message: 'Cart cleared successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to clear cart' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


